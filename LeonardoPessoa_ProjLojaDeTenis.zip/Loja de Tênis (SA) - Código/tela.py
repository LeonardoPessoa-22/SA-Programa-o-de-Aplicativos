import os
from tkinter import *
from tkinter import font
import tkinter as tk
from tkinter.ttk import Style
from tkinter import messagebox

from Database import Database
from Usuarios import Usuarios

import mysql.connector

HOST = "localhost"
USER = "root"
PASSWORD = "root"
DATABASE = "loja_de_tenis"

# ------------------- FUNÇÕES ------------------------- #

# Classe para limpar campos
class LimparCampos():
    def clean_cadastro(self, txt_nome, txt_email, txt_telefone, txt_endereco, txt_senha):
        txt_nome.delete(0, tk.END)
        txt_email.delete(0, tk.END)
        txt_telefone.delete(0, tk.END)
        txt_endereco.delete(0, tk.END)
        txt_senha.delete(0, tk.END)

cleaner = LimparCampos()


# ------------- FUNÇÃO DE CADASTRO ------------------ #
def registrar_usuario():
    nome = txt_nome.get()
    email = txt_email.get()
    telefone = txt_telefone.get()
    endereco = txt_endereco.get()
    senha = txt_senha.get()

    # ----- Check if all fields are filled ------ #
    if not nome or not email or not telefone or not endereco or not senha:
        messagebox.showerror("Erro! Por favor, preencha todos os campos.")
        return

    try:
        # ----- Connect to the database ----- #
        conn = mysql.connector.connect(host=HOST, user=USER, password=PASSWORD, database=DATABASE)
        cursor = conn.cursor()

        # Check if user already exists (using email, telefone, as a unique identifier)
        sql = "SELECT * FROM usuarios WHERE email = %s OR telefone = %s"
        val = (email, telefone)
        cursor.execute(sql, val)
        result = cursor.fetchone()

        if result:
            messagebox.showerror("Erro! Já existe um usuário com este email ou telefone.")
            return

        # ---- Insert user data into the database ------ #
        sql = "INSERT INTO usuarios (nome, email, telefone, endereco, senha) VALUES (%s, %s, %s, %s, %s)"
        val = (nome, email, telefone, endereco, senha)
        cursor.execute(sql, val)
        conn.commit()

        messagebox.showinfo("Cadastro realizado com sucesso!")
        cleaner.clean_cadastro(txt_nome, txt_email, txt_telefone, txt_endereco, txt_senha)

    except mysql.connector.Error as err:
        messagebox.showerror("Erro", f"Erro ao cadastrar usuário: {err}")
    finally:
        # Close the database connection (if open)
        if conn:
            conn.close()


# ------------- FUNÇÃO DE LOGIN ------------------ #
def tela_login():
    frame_login.place(width=750, height=550)
    lbl_email_login = Label(frame_login, text="Email:")
    lbl_email_login.place(x=250, y=150)
    txt_email_login = Entry(frame_login, width=30)
    txt_email_login.place(x=310, y=152)

    lbl_senha_login = Label(frame_login, text="Senha:")
    lbl_senha_login.place(x=250, y=180)
    txt_senha_login = Entry(frame_login, width=30, show="*")
    txt_senha_login.place(x=310, y=182)

    # Botão para verificar o login
    btn_login = Button(frame_login, text="Login", command=lambda: verificar_login(frame_login))
    btn_login.place(x=380, y=230) 

    def verificar_login(frame_login):
            email = txt_email_login.get()
            senha = txt_senha_login.get()

            admin_email = "adm"
            admin_senha = "123"

            if not email or not senha:
                messagebox.showerror("Erro! Por favor, preencha todos os campos obrigatórios.")
                return

            # Verifica se é o administrador
            if email == admin_email and senha == admin_senha:
                messagebox.showinfo("Sucesso", "Bem-vindo, administrador!")
                frame_login.place_forget()
                frame_admin.place(width=500, height=400)
                tela_admin()
                return  # Encerra a função após o login de administrador

            try:
                conn = mysql.connector.connect(host=HOST, user=USER, password=PASSWORD, database=DATABASE)
                cursor = conn.cursor()

                # Consultar o banco de dados para verificar as credenciais
                sql = "SELECT senha FROM usuarios WHERE email = %s"
                val = (email,)
                cursor.execute(sql, val)
                resultado = cursor.fetchone()

                if resultado:
                    senha_armazenada = resultado[0]
                    if senha == senha_armazenada:
                        messagebox.showinfo("Sucesso", "Login realizado com sucesso!")
                        frame_login.place_forget()
                        frame_funcionario.place(width=500, height=400)
                        tela_funcionario()
                    else:
                        messagebox.showerror("Erro", "Senha incorreta.")
                else:
                    messagebox.showerror("Erro!", "Dados incorretos.")

            except mysql.connector.Error as err:
                messagebox.showerror("Erro", f"Erro ao verificar login: {err}")
            finally:
                if conn:
                    conn.close()


# ------------- TELA PRODUTO FUNÇÕES     ------------------ #

def salvar_produto(modelo, categoria, tamanho, cor, preco, cd_fornecedor):

    try:
        conn = mysql.connector.connect(host=HOST, user=USER, password=PASSWORD, database=DATABASE)
        cursor = conn.cursor()

        # Consultar o banco de dados para verificar as credenciais
        sql = "INSERT INTO produto (modelo, categoria, tamanho, cor, preco, cd_fornecedor) VALUES (%s, %s, %s, %s, %s, %s)"
        val = (modelo, categoria, tamanho, cor, preco, cd_fornecedor)
        cursor.execute(sql, val)
        conn.commit()

        id_produto = cursor.lastrowid
        messagebox.showinfo("Produto cadastrado com sucesso!", f"ID: {id_produto}")

    finally:
        if conn:
            conn.close()

def salvar_fornecedor(nm_fornecedor):

    try:
        conn = mysql.connector.connect(host=HOST, user=USER, password=PASSWORD, database=DATABASE)
        cursor = conn.cursor()

        sql = "INSERT INTO fornecedor (nm_fornecedor) VALUES (%s)"
        val = (nm_fornecedor,)
        cursor.execute(sql, val)
        conn.commit()

        cd_fornecedor = cursor.lastrowid
        messagebox.showinfo("Fornecedor cadastrado com sucesso!", f"ID: {cd_fornecedor}")

    finally:
        if conn:
            conn.close()

def editar_fornecedor(txt_nome_fornecedor_edit, txt_cd):

    conn = mysql.connector.connect(host=HOST, user=USER, password=PASSWORD, database=DATABASE)
    cursor = conn.cursor()

    sql = "UPDATE fornecedor SET nm_fornecedor=%s WHERE cd_fornecedor=%s"
    val = (txt_nome_fornecedor_edit, txt_cd)
    cursor.execute(sql, val)
    conn.commit()
    conn.close()
    messagebox.showinfo("Fornecedor editado com sucesso!")

def excluir_fornecedor(cd_fornecedor):
    conn = mysql.connector.connect(host=HOST, user=USER, password=PASSWORD, database=DATABASE)
    cursor = conn.cursor()

    sql = "DELETE FROM fornecedor WHERE cd_fornecedor = %s"
    val = (cd_fornecedor,)
    cursor.execute(sql, val)
    conn.commit()
    messagebox.showinfo("Fornecedor excluído com sucesso!")


def editar_produto(txt_id, txt_modelo_edit, txt_categoria_edit, txt_tamanho_edit, txt_cor_edit, txt_preco_edit):

    conn = mysql.connector.connect(host=HOST, user=USER, password=PASSWORD, database=DATABASE)
    cursor = conn.cursor()

    sql = "UPDATE produto SET modelo=%s, categoria=%s, tamanho=%s, cor=%s, preco=%s WHERE id_produto=%s"
    val = (txt_modelo_edit, txt_categoria_edit, txt_tamanho_edit, txt_cor_edit, txt_preco_edit, txt_id)
    cursor.execute(sql, val)
    conn.commit()
    conn.close()
    messagebox.showinfo("Produto editado com sucesso!")

def excluir_produto(id_produto):
    conn = mysql.connector.connect(host=HOST, user=USER, password=PASSWORD, database=DATABASE)
    cursor = conn.cursor()

    sql = "DELETE FROM produto WHERE id_produto = %s"
    val = (id_produto,)
    cursor.execute(sql, val)
    conn.commit()
    messagebox.showinfo("Produto excluído com sucesso!")

def pesquisar_produto(id_produto, lbl_resultado_pesquisa):

    conn = mysql.connector.connect(host=HOST, user=USER, password=PASSWORD, database=DATABASE)
    cursor = conn.cursor()

    sql = "SELECT * FROM produto WHERE id_produto = %s"
    val = (id_produto,)
    cursor.execute(sql, val)
    resultado = cursor.fetchone()

    if resultado:
        lbl_resultado_pesquisa.config(text=f"ID: {resultado[0]}        Modelo: {resultado[1]}        Categoria: {resultado[2]}        Tamanho: {resultado[3]}        Cor: {resultado[4]}        Preço: {resultado[5]}        Fornecedor: {resultado[6]}")
    else:
        lbl_resultado_pesquisa.config(text="Produto não encontrado.")
    
    conn.close()

def pesquisar_fornecedor(cd_fornecedor, lbl_resultado_pesquisa_fornecedor):

    conn = mysql.connector.connect(host=HOST, user=USER, password=PASSWORD, database=DATABASE)
    cursor = conn.cursor()

    sql = "SELECT * FROM fornecedor WHERE cd_fornecedor = %s"
    val = (cd_fornecedor,)
    cursor.execute(sql, val)
    resultado = cursor.fetchone()

    if resultado:
        lbl_resultado_pesquisa_fornecedor.config(text=f"ID: {resultado[0]}        Nome do Fornecedor: {resultado[1]}")
    else:
        lbl_resultado_pesquisa_fornecedor.config(text="Fornecedor não encontrado.")
    
    conn.close()



# ------------- TELA DO ADMIN ------------------ #
def tela_admin():
    frame_admin.place(width=750, height=550)

    Button(frame_admin, text="Tela de produtos", command=tela_produto).place(x=310, y=20)
    Button(frame_admin, text="Tela de fornecedor", command=tela_fornecedor).place(x=310, y=60)

def tela_produto():
    frame_produto.place(width=750, height=550)

    lbl_pesquisar = Label(frame_produto, text="ID do produto:")
    lbl_pesquisar.place(x=180, y=50)
    txt_pesquisar = Entry(frame_produto, width=10)
    txt_pesquisar.place(x=265, y=50)
    lbl_resultado_pesquisa = Label(frame_produto, text="", bg="white", width=102)
    lbl_resultado_pesquisa.place(x=10, y=100)
    Button(frame_produto, text="Pesquisar", command=lambda: pesquisar_produto(txt_pesquisar.get(), lbl_resultado_pesquisa)).place(x=330, y=50)

    # CADASTRO PRODUTO ---------------------------- #
    lbl_modelo = Label(frame_produto, text="Modelo:")
    lbl_modelo.place(x=50, y=150)
    txt_modelo = Entry(frame_produto, width=30)
    txt_modelo.place(x=140, y=152)

    lbl_categoria = Label(frame_produto, text="Categoria:")
    lbl_categoria.place(x=50, y=180)
    txt_categoria = Entry(frame_produto, width=30)
    txt_categoria.place(x=140, y=182)

    lbl_tamanho = Label(frame_produto, text="Tamanho:")
    lbl_tamanho.place(x=50, y=210)
    txt_tamanho = Entry(frame_produto, width=30)
    txt_tamanho.place(x=140, y=212)

    lbl_cor = Label(frame_produto, text="Cor:")
    lbl_cor.place(x=50, y=240)
    txt_cor = Entry(frame_produto, width=30)
    txt_cor.place(x=140, y=242)

    lbl_preco = Label(frame_produto, text="Preço:")
    lbl_preco.place(x=50, y=270)
    txt_preco = Entry(frame_produto, width=30)
    txt_preco.place(x=140, y=272)

    lbl_fornecedor = Label(frame_produto, text="Fornecedor:")
    lbl_fornecedor.place(x=50, y=300)
    txt_fornecedor = Entry(frame_produto, width=30)
    txt_fornecedor.place(x=140, y=302)

    btn_salvar_produto = Button(frame_produto, text="Salvar Produto", command=lambda: salvar_produto(
        txt_modelo.get(), txt_categoria.get(), txt_tamanho.get(), txt_cor.get(), txt_preco.get(), txt_fornecedor.get()
    ))
    btn_salvar_produto.place(x=180, y=322)

    # EDITAR PRODUTO -------------------------- #
    lbl_id = Label(frame_produto, text="ID:")
    lbl_id.place(x=460, y=125)
    txt_id = Entry(frame_produto, width=10)
    txt_id.place(x=500, y=127)

    lbl_modelo_edit = Label(frame_produto, text="Modelo:")
    lbl_modelo_edit.place(x=450, y=150)
    txt_modelo_edit = Entry(frame_produto, width=30)
    txt_modelo_edit.place(x=540, y=152)

    lbl_categoria_edit = Label(frame_produto, text="Categoria:")
    lbl_categoria_edit.place(x=450, y=180)
    txt_categoria_edit = Entry(frame_produto, width=30)
    txt_categoria_edit.place(x=540, y=182)

    lbl_tamanho_edit = Label(frame_produto, text="Tamanho:")
    lbl_tamanho_edit.place(x=450, y=210)
    txt_tamanho_edit = Entry(frame_produto, width=30)
    txt_tamanho_edit.place(x=540, y=212)

    lbl_cor_edit = Label(frame_produto, text="Cor:")
    lbl_cor_edit.place(x=450, y=240)
    txt_cor_edit = Entry(frame_produto, width=30)
    txt_cor_edit.place(x=540, y=242)

    lbl_preco_edit = Label(frame_produto, text="Preço:")
    lbl_preco_edit.place(x=450, y=270)
    txt_preco_edit = Entry(frame_produto, width=30)
    txt_preco_edit.place(x=540, y=272)

    Button(frame_produto, text="Editar produto", command=lambda: editar_produto(
        txt_id.get(), txt_modelo_edit.get(), txt_categoria_edit.get(), txt_tamanho_edit.get(), txt_cor_edit.get(), txt_preco_edit.get()
    )).place(x=580, y=322)

    # EXCLUIR PRODUTO ----------------------------------------- #
    Button(frame_produto, text="Excluir produto", command=lambda: excluir_produto(txt_id.get())).place(x=620, y=50)


# ------------- TELA DO FUNCIONÁRIO ------------------ #

def tela_funcionario():
    frame_funcionario.place(width=750, height=550)

    lbl_pesquisar = Label(frame_funcionario, text="ID do produto:")
    lbl_pesquisar.place(x=180, y=50)
    txt_pesquisar = Entry(frame_funcionario, width=10)
    txt_pesquisar.place(x=265, y=50)
    lbl_resultado_pesquisa = Label(frame_funcionario, text="", bg="white", width=102)
    lbl_resultado_pesquisa.place(x=10, y=100)
    Button(frame_funcionario, text="Pesquisar", command=lambda: pesquisar_produto(txt_pesquisar.get(), lbl_resultado_pesquisa)).place(x=330, y=50)

    lbl_pesquisar_fornecedor = Label(frame_funcionario, text="ID do fornecedor:")
    lbl_pesquisar_fornecedor.place(x=180, y=350)
    txt_pesquisar_fornecedor = Entry(frame_funcionario, width=10)
    txt_pesquisar_fornecedor.place(x=285, y=350)
    lbl_resultado_pesquisa_fornecedor = Label(frame_funcionario, text="", bg="white", width=102)
    lbl_resultado_pesquisa_fornecedor.place(x=10, y=400)
    Button(frame_funcionario, text="Pesquisar fornecedor", command=lambda: pesquisar_fornecedor(txt_pesquisar_fornecedor.get(), lbl_resultado_pesquisa_fornecedor)).place(x=350, y=350)


def tela_fornecedor():
    frame_fornecedor.place(width=750, height=550)

    lbl_pesquisar_fornecedor = Label(frame_fornecedor, text="ID do fornecedor:")
    lbl_pesquisar_fornecedor.place(x=180, y=50)
    txt_pesquisar_fornecedor = Entry(frame_fornecedor, width=10)
    txt_pesquisar_fornecedor.place(x=285, y=50)
    lbl_resultado_pesquisa_fornecedor = Label(frame_fornecedor, text="", bg="white", width=102)
    lbl_resultado_pesquisa_fornecedor.place(x=10, y=100)
    Button(frame_fornecedor, text="Pesquisar", command=lambda: pesquisar_fornecedor(txt_pesquisar_fornecedor.get(), lbl_resultado_pesquisa_fornecedor)).place(x=350, y=50)

    # Cadastrar Fornecedor -------------------- #
    lbl_nome_fornecedor = Label(frame_fornecedor, text="Nome do fornecedor:")
    lbl_nome_fornecedor.place(x=50, y=150)
    txt_nome_fornecedor = Entry(frame_fornecedor, width=15)
    txt_nome_fornecedor.place(x=200, y=152)

    btn_salvar_fornecedor = Button(frame_fornecedor, text="Cadastrar Fornecedor", command=lambda: salvar_fornecedor(
        txt_nome_fornecedor.get()
    ))
    btn_salvar_fornecedor.place(x=180, y=182)

    # Editar Fornecedor -------------------- #
    lbl_cd = Label(frame_fornecedor, text="Código do Fornecedor:")
    lbl_cd.place(x=350, y=125)
    txt_cd = Entry(frame_fornecedor, width=10)
    txt_cd.place(x=500, y=127)

    lbl_nome_fornecedor_edit = Label(frame_fornecedor, text="Nome do fornecedor:")
    lbl_nome_fornecedor_edit.place(x=350, y=150)
    txt_nome_fornecedor_edit = Entry(frame_fornecedor, width=15)
    txt_nome_fornecedor_edit.place(x=500, y=152)

    btn_editar_fornecedor = Button(frame_fornecedor, text="Editar Fornecedor", command=lambda: editar_fornecedor(
        txt_nome_fornecedor_edit.get(), txt_cd.get()
    ))
    btn_editar_fornecedor.place(x=480, y=182)

    # Excluir Fornecedor -------------------- #
    Button(frame_fornecedor, text="Excluir fornecedor", command=lambda: excluir_fornecedor(txt_cd.get())).place(x=620, y=50)


def voltar_tela_admin():
    frame_produto.place_forget()
    frame_fornecedor.place_forget()

def voltar():
    frame_login.place_forget()
    frame_admin.place_forget()
    frame_funcionario.place_forget()

# ------------- TELA INICIAL DE CADASTRO --------------- #

root = tk.Tk()
root.geometry("750x550")
root.configure(bg="lightblue")
Label(root, text="Bem vindo a Loja NIKE", fg="black", font=("Arial", 16, "bold")).pack(pady=20)


lbl_nome = Label(root, text="Nome:")
lbl_nome.place(x=250, y=150)
txt_nome = Entry(root, width=30)
txt_nome.place(x=310, y=152)

lbl_email = Label(root, text="Email:")
lbl_email.place(x=250, y=180)
txt_email = Entry(root, width=30)
txt_email.place(x=310, y=182)

lbl_telefone = Label(root, text="Telefone:")
lbl_telefone.place(x=250, y=210)
txt_telefone = Entry(root, width=30)
txt_telefone.place(x=310, y=212)

lbl_endereco = Label(root, text="Endereço:")
lbl_endereco.place(x=250, y=240)
txt_endereco = Entry(root, width=30)
txt_endereco.place(x=310, y=242)

lbl_senha = Label(root, text="Senha:")
lbl_senha.place(x=250, y=270)
txt_senha = Entry(root, width=30, show="*")
txt_senha.place(x=310, y=272)

Button(root, text="Confirmar Cadastro", command=registrar_usuario).place(x=290, y=320)

Button(root, text="Fazer Login", command= tela_login).place(x=420, y=320)


# --------- CONFIGURAÇÕES DE OUTRAS TELAS ------- #
frame_login = Frame(root, bg="lightblue")
Button(frame_login, text="Voltar", command=voltar).place(x=310, y=230)


frame_admin = Frame(root, bg="lightblue")
Button(frame_admin, text="Sair", command=voltar).place(x=20, y=20)

frame_produto = Frame(root, bg="lightblue")
Button(frame_produto, text="Voltar", command=voltar_tela_admin).place(x=20, y=20)

frame_fornecedor = Frame(root, bg="lightblue")
Button(frame_fornecedor, text="Voltar", command=voltar_tela_admin).place(x=20, y=20)

frame_funcionario = Frame(root, bg="lightblue")
Button(frame_funcionario, text="Voltar", command=voltar).place(x=310, y=230)



root.mainloop()